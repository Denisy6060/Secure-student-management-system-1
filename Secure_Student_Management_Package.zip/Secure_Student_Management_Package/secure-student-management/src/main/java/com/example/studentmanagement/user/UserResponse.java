package com.example.studentmanagement.user;

// DTO: what we send to the client (no password!)
public record UserResponse(Long id, String username, Role role) {

    public static UserResponse from(User user) {
        return new UserResponse(user.getId(), user.getUsername(), user.getRole());
    }
}
