package com.example.studentmanagement.user;

public enum Role {
    ADMIN,
    USER
}
