package com.example.studentmanagement.config;

import com.example.studentmanagement.student.Student;
import com.example.studentmanagement.student.StudentRepository;
import com.example.studentmanagement.user.Role;
import com.example.studentmanagement.user.User;
import com.example.studentmanagement.user.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final PasswordEncoder passwordEncoder;
    private final String adminUsername;
    private final String adminPassword;

    public DataInitializer(UserRepository userRepository,
                           StudentRepository studentRepository,
                           PasswordEncoder passwordEncoder,
                           @Value("${app.admin.username}") String adminUsername,
                           @Value("${app.admin.password}") String adminPassword) {
        this.userRepository = userRepository;
        this.studentRepository = studentRepository;
        this.passwordEncoder = passwordEncoder;
        this.adminUsername = adminUsername;
        this.adminPassword = adminPassword;
    }

    @Override
    public void run(String... args) {
        if (!userRepository.existsByUsername(adminUsername)) {
            userRepository.save(new User(adminUsername, passwordEncoder.encode(adminPassword), Role.ADMIN));
        }

        if (studentRepository.count() == 0) {
            studentRepository.save(newStudent("Amina", "Juma", "amina@example.com", "REG001", "Computer Engineering"));
            studentRepository.save(newStudent("John", "Mushi", "john@example.com", "REG002", "Electrical Engineering"));
        }
    }

    private Student newStudent(String first, String last, String email, String reg, String course) {
        Student s = new Student();
        s.setFirstName(first);
        s.setLastName(last);
        s.setEmail(email);
        s.setRegistrationNumber(reg);
        s.setCourse(course);
        return s;
    }
}
