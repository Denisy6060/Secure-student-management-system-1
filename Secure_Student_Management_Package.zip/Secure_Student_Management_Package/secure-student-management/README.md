# Secure Student Management System

Spring Boot 3 REST API with JWT authentication, refresh tokens and role-based access (ADMIN / USER).

## Run
```
mvn spring-boot:run
```
Default admin (created on startup): `admin` / `Admin@123` (change in `application.properties`).

## Endpoints
| Method | URL | Access |
|---|---|---|
| POST | /api/auth/register | public |
| POST | /api/auth/login | public |
| POST | /api/auth/refresh | public (needs refresh token) |
| POST | /api/auth/logout | public (needs refresh token) |
| GET | /api/students, /api/students/{id} | any logged-in user |
| POST / PUT / DELETE | /api/students | ADMIN only |
| GET | /api/users/me | any logged-in user |
| GET | /api/users | ADMIN only |

Send the access token as `Authorization: Bearer <token>`.
